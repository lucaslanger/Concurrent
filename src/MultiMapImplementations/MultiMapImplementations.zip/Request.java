package MultiMapImplementations;

import java.util.Collection;
import java.util.Random;

public final class Request{
	private static final int request_types = 4;
	private final static String[] keys = {"Lucas"};//, "Mike", "Willie", "Corinna", "Jonas"};
	private final static String[] values = {"Halt and Catch Fire", "Silicon Valley"};//, "Simpsons", "Family Guy", "Homeland"};

	private static Random r = new Random();
	
	private final String key;
	private final String value;
	private final String type;
	private Collection<String> result;
	
	public Request(String type, String key, String value){ 
		this.type = type;
		this.key = key;
		this.value = value;
	}
	
	public void executeRequest(LocallyLockingMultiMap<String, String> database){
		switch(this.type){
			case "GET":
				result = database.get(this.key); 
				break;
				
			case "WRITE":
				database.put(this.key, this.value);
				break;
				
			case "REMOVE":
				database.remove(this.key);
				break;
		}
	}
	
	public void printRequest(String caller_id){
		switch(this.type){
			case "WRITE":
				System.out.format("%s, %s  %s, VALUE: %s %n", caller_id, this.type, this.key, this.value );
				break;
			case "REMOVE":
				System.out.format("%s, %s %s, %n", caller_id, this.type, this.key );
				break;
			case "GET":
				System.out.format("%s, %s %s, RESULT: %s %n", caller_id, this.type, this.key, this.result );
				break;
		}
	}
	
	public static Request randomRequest(){
		 Request request = null;
		 int i = r.nextInt(Request.request_types);
		 String key = randomKey();
		 String value;
		 switch (i) {
		 case 0:
			 request = new Request("GET", key, null);
			 break;
			 
		 case 1:
			 request = new Request("REMOVE", key, null);
			break;
			
		 case 2:
			 value = randomValue();
			 request = new Request("WRITE", key, value);
			 break;
		 
		 case 3:
			 value = randomValue();
			 request = new Request("REMOVE_VALUE", key, value);
		
		}
		 return request;
	}
	
	private static String randomKey(){
		return Request.keys[r.nextInt(Request.keys.length)];
	}
	
	private static String randomValue(){
		return Request.values[r.nextInt(Request.values.length)];
	}
}
